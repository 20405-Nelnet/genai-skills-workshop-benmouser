# Aurora Bay Agent Test Plan

Use these questions to verify that the agent retrieves answers from the Aurora Bay FAQ data store instead of making up unsupported responses.

## Expected FAQ Questions

1. What are City Hall hours?
2. How do I report a pothole?
3. How do I apply for a building permit?
4. When is trash pickup delayed?
5. How do I contact Aurora Bay city services?

## Unsupported / Hallucination Test

Ask a question that should not be in the FAQ data:

> What is the mayor's favorite football team?

Expected behavior:

The agent should state that it cannot find that information in the available Aurora Bay FAQ knowledge source, rather than inventing an answer.

## Success Criteria

- The agent answers FAQ-style questions using the attached data store.
- The agent does not fabricate unsupported city facts.
- The agent asks clarifying questions when the user's question is unclear.
- The exported agent package includes the playbook, tool, and data store reference.
