# Bonus Challenge 4 - Aurora Bay Agent Artifacts

This folder contains supporting artifacts for the AI Applications / Conversational Agent bonus challenge.

## Challenge Goal

Create a conversational agent for the fictional town of Aurora Bay, Alaska. The agent should answer citizen FAQ questions using an AI Applications data store connected to the Aurora Bay FAQ content.

## Artifact Contents

- `Day1Lab4_exported_agent_Aurora_Bay_Agent.zip` - exported AI Applications agent package.
- `exported_agent_extracted/` - extracted copy of the agent export for review.
- `agent_summary.json` - summary of the agent, playbook, tool, and data store metadata.
- `playbook_goal.md` - playbook goal text.
- `playbook_instructions.md` - playbook instructions text.
- `test_plan.md` - suggested validation questions for the Aurora Bay FAQ agent.

## Agent Summary

- Agent name: **Aurora Bay Agent**
- Start playbook: **Aurora Bay Playbook**
- Playbook: **Aurora Bay Playbook**
- Tool: **Aurora Bay Agent FAQ**
- Data store: **Aurora Bay FAQs**
- Data store type: **UNSTRUCTURED**

## Submission Note

For grading, upload the exported agent package or the extracted exported agent folder to the public GitHub repository for the workshop.
